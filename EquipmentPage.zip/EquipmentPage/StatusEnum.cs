﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EquipmentPage;

public enum StatusEnum
{
    Bereit = 0,
    InWartung = 1,
    Defekt = 2,
}

